package com.capgemini.test;   

import static org.junit.Assert.*;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.capgemini.bean.Customerbean;
import com.capgemini.dao.CustomerDaoImpl;
import com.capgemini.exception.CustomersException;


public class CustomerDaoTest {

    static CustomerDaoImpl dao;
    static Customerbean customerbean;

    @BeforeClass
    public static void initialize() {
        dao = new CustomerDaoImpl();
        customerbean = new Customerbean();
    }

    @Test
    public void testAddDonarDetails() throws CustomersException {

        assertNotNull(dao.addCustomerDetails(customerbean));
    }
    
    /************************************
     * Test case for addCustomerDetails()
     * 
     ************************************/

    @Ignore
    @Test
    public void testAddDonarDetails1() throws CustomersException {
        assertEquals(1001, dao.addCustomerDetails(customerbean));
    }

    /************************************
     * Test case for addCustomerDetails()
     * 
     ************************************/

    @Test
    public void testAddCustomerDetails2() throws CustomersException {
        
        customerbean.setName("com");
        customerbean.setPhoneNumber("9000342237");
        customerbean.setAge("22");
        customerbean.setProductInterested("apple");
        assertTrue("Data Inserted successfully",
                Integer.parseInt(dao.addCustomerDetails(customerbean)) > 1000);

    }
}
